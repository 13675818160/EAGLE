package com.spring.boot.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Created by maobg on 2015/7/18.
 */
@ConfigurationProperties(prefix = "application")
public class ApplicationProperties {


}
